// import { useState } from 'react';

// const Input = (props) => {
//     const [listItem, setListItem] = useState(''); 
//     //console.log('rendering Input Component');

//     const inputChangeHandler = (e) => {
//         const item = e.target.value;
//         setListItem(item);
//     }

//     const buttonClickHandler = () => {
//         const withoutSpaceItem = listItem.trim();
//         if(withoutSpaceItem){
//             props.addListItemHandler(withoutSpaceItem);
//         }
//         setListItem('');
//     }

//     return (
//         <div>
//             <input 
//                 type="input" 
//                 value={listItem} 
//                 onChange={inputChangeHandler}
//             />
//             <button 
//                 onClick={buttonClickHandler}
//             >
//                 Add Costemer
//             </button>
//         </div>
//     );
// }


import React, { Component } from "react";
 
class Input extends Component {
  render() {
    return (
      <div className="todoListMain">
        <div className="header">
          <form>
            <input placeholder="enter name">
            </input>
            <button type="submit">add</button>
          </form>
        </div>
      </div>
    );
  }
}

addItem(e) 
    if (this._inputElement.value !== "") {
      var newItem = {
        text: this._inputElement.value,
        key: Date.now()
      };
   
      this.setState((prevState) => {
        return { 
          items: prevState.items.concat(newItem) 
        };
      });
     
      this._inputElement.value = "";
    }
     
    console.log(this.state.items);
       
    e.preventDefault();


export default Input;